# Author: OMKAR PATHAK

# Python program to reverse the words

userInput = input()
userInput = userInput.split()

print(' '.join(userInput[::-1]))

# OUTPUT:
# Computer Science
# Science Computer
