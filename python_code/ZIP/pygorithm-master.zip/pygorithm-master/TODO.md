# TODO

### Tree

- [x] Binary Tree
- [ ] Binary Search Tree
- [ ] Inorder to Preorder
- [ ] Count Leaf Nodes

### Graph

- [ ] Graph implementation
- [ ] Detect cycle in Graph
- [ ] Topological Sort
- [ ] Prim's Algorithm
- [ ] Kruskal's Algorithm

### Dynamic Programming

- [ ] Fibonacci
- [ ] Longest Increasing Subsequence

### Heap

- [ ] Heap  implementation
- [ ] Heap Sort
