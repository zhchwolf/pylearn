const lib = require('./lib.js');

Page(lib.gen_page('Month'))