# Define the path to the DNSMasq Lease file
dnsmasq_lease_file = '/var/lib/misc/dnsmasq.leases'

# Read list of hosts to ping from csv file ping_hosts
ping_hosts = 'ping_hosts'
