"""
python-social-auth application, allows OpenId or OAuth user
registration/authentication just adding a few configurations.
"""
version = (0, 1, 2)
extra = ''
__version__ = '.'.join(map(str, version)) + extra
