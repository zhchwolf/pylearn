l0 = 0
l1 = 63
l2 = 127
l3 = 255

BLACK = [l0, l0, l0]
DGRAY = (l1, l1, l1)
LGRAY = (l2, l2, l2)
WHITE = (l3, l3, l3)

LRED = (l3, l2, l2)
RED = (l3, l0, l0)
DRED = (l2, l0, l0)

LYELLOW = (l3, l3, l2)
YELLOW = (l3, l3, l1)
DYELLOW = (l2, l2, l1)

LORANGE = (l3, l3, l1)
ORANGE = (l3, l3, l0)
DORANGE = (l2, l2, l0)

LGREEN = (l2, l3, l2)
GREEN = (l0, l3, l0)
DGREEN = (l0, l2, l0)

LBLUE = (l2, l2, l3)
BLUE = (l0, l0, l3)
DBLUE = (l0, l0, l2)

LCYAN = (l2, l3, l3)
CYAN = (l0, l3, l3)
DCYAN = (l0, l2, l2)

LVIOLET = (l3, l2, l3)
VIOLET = (l3, l0, l3)
DVIOLET = (l2, l0, l2)
