service CalcService {
    i64 add(1:i64 a, 2:i64 b),
}