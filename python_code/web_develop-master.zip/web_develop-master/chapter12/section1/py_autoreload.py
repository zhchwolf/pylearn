# coding=utf-8
def a():
    return 2
