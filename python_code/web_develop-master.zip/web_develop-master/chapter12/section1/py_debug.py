# coding=utf-8
a = 1
b = 0

a / b
