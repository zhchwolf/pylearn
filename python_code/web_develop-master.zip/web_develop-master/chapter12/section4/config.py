# coding=utf-8
DEBUG = True
SQLALCHEMY_DATABASE_URI = 'mysql://web:web@localhost:3306/r'
UPLOAD_FOLDER = 'permdir'
SQLALCHEMY_TRACK_MODIFICATIONS = False
