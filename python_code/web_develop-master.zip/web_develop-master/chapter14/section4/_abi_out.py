# auto-generated file
import _cffi_backend

ffi = _cffi_backend.FFI('_abi_out',
    _version = 0x2601,
    _types = b'\x00\x00\x01\x0D\x00\x00\x0E\x01\x00\x00\x00\x0F',
    _globals = (b'\x00\x00\x00\x23ceil',0,),
)
