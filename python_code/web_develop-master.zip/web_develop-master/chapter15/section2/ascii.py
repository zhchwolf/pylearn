# coding=utf-8
story_tags = [
    (('xxxxxx', 38), [('xxxx', 39),
                      ('xxxx', 40)]),
]
