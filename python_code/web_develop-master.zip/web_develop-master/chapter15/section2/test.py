import asv


def ashs(numb, lala, **kw):
    return numb + 2


def ashsss(numb, lala, **kw):
    print 'sddd'
    return numb + 2


ashs(10)
