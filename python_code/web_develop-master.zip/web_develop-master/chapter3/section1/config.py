# coding=utf-8
DEBUG = False

try:
    from local_settings import *
except ImportError:
    pass
