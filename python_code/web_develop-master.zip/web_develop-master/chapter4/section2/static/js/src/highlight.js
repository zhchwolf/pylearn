console.log('In highlight');
