# coding=utf-8
from flask_mako import MakoTemplates, render_template  # noqa

mako = MakoTemplates()
