## How to run

```
pip install -r requirements.txt

python wut4lunch.py

# go to http://localhost:5000/
```
